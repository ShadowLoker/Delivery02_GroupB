# SNEAKY
An oldie but goodie stealth game, written in C# and made with Unity.

## INTRODUCTION
Sneaky is a 2d top-down stealth game made by four college students as a project for our 2d game development subject. We went beyond and did more than we were asked to in order to learn as much as we could and to deliver something beautiful and taken care of.
We hope you can enjoy grading this as much as we did creating it. 

## HOW TO PLAY
- Move arround the museum and collect all gemstones
- Avoid all the guards and don't let them hear you
- Guards will chase you
- Grabbing gemstones will slow you down, so watch out for speedy guards

## CONTROLS
- WASD for movement
- SHIFT for crouch
- ESCAPE to go to the main menu
- ENTER to start/restart game

