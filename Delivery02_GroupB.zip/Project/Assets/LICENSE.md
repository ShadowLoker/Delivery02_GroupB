Sneaky © 2024 by Catsoup is licensed under Attribution-NonCommercial-ShareAlike 4.0 International. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/

Every Asset used in the game was created by us with Asesprite and FLStudio